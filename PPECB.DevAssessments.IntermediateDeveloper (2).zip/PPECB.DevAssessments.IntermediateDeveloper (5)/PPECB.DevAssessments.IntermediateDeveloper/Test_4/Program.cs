﻿using System;

namespace Test_4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Write a function that swaps the first pair (1st and 2nd characters) with the second pair
            // (3rd and 4th characters) for every quadruplet substring.

            SwapTwo("ABCDEFGH"); //Should return "CDABGHEF"

        }

        public static string SwapTwo(string text)
        {
            int length = text.Length;
            int len = 0;
            int rmd   = len % length;
            string results = "";
            if(rmd == 0)
            {
                return results;
            }
            int b = 0;
            int f = b / length;
            int r = b % len;

            string pone = rotateLeft(text.Substring(0,rmd),
                ((len % rmd) * f)% rmd );

            string ptwo = rotateLeft(text.Substring(rmd),
                ((rmd * f) % (len - rmd)));
            //here I was going for loop for swapping for swaping reminder
            return text;
        }

        private static string rotateLeft(string s, int p )
        {
            return s.Substring(p) + s.Substring(0, p);
        }

        
    }
}
