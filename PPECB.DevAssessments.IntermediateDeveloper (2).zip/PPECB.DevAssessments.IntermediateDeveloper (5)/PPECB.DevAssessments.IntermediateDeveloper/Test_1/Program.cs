﻿using System;
using System.IO;
using System.Text;

namespace Test_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a function that returns the selected filename from a path.Include the extension in your answer.

            GetFilename("C:/Projects/pil_tests/ascii/test.txt"); //Should return "test.txt"
        }

        public static string GetFilename(string path)
        {
            string strPath = "C:/Projects/pil_tests/ascii/test.txt";
             path = Path.GetFileName(strPath);
            Console.WriteLine( path);
            Console.ReadLine();

            return path;
        }
    }
  
}
