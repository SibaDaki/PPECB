﻿using System;

namespace Test_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a function that moves all capital letters to the front of a word.

            CapToFront("moveMENT"); //Should return "MENTmove"
        }

        public static string CapToFront(string text)
        {
            int length = text.Length;
            string lower = "";
            string upper = "";
            char ch;

            for(int i = 0; i < length; i++)
            {
                ch = text[i];

                if (ch >= 'A' && ch <= 'Z')
                    upper += ch;
                else
                    lower += ch;
            }

            Console.WriteLine(upper + lower);
            Console.ReadLine();


            return text;
        }
    }
}
