﻿using System;

namespace PPECB.DevAssessments.IntermediateDeveloper
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
